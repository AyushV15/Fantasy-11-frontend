import { createContext } from "react";

export const MatchContext = createContext()