import { Image } from "react-bootstrap"
import one from "../../Images/1.png"
import two from "../../Images/2.png"
import { Schema } from "yup"

export default function FantasyScoreSystem(){
    return(
        <div style={{
            display : "flex",
            flexDirection : "column",
            justifyContent : "center",
            alignItems : "center"
        }}>
          <Image src={one} width={800}/>
          <Image src={two} width={800}/>
        </div>
    )
}

