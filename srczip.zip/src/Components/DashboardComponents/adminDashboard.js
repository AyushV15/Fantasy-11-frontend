import { useEffect, useReducer, useState } from "react"
import axios from "../../Axios/axios"
import { Tab, Tabs,Col , Row ,Table, Button, InputGroup} from "react-bootstrap"
import "./adminDashboard.css"
import io from "socket.io-client";
const socket = io.connect("http://localhost:3300")

const test = () =>{
    alert("clicked")
    const name = "ayush"
    socket.emit("hi",name)
}


const reducer = (state,action) =>{
        switch(action.type){
            case "SET_USERS" : {
                return [...state,...action.payload]
            }
            case "UPDATE_USERS" : {
                return state.map(ele =>{
                    if(ele._id == action.payload._id){
                        return {...ele,...action.payload}
                    }else{
                        return {...ele}
                    }
                })
            }
            default : {
                return [...state]
            }
        }
}

export default function AdminDashboard(){

    const [users,dispatch] = useReducer(reducer,[])  
    const [matches,setMatches] = useState([])
    const [search,setSearch] = useState('')

    useEffect(()=>{
        socket.on("someEvent",(data)=>{
            alert(data)
        })
    },[socket])
    
    useEffect(()=>{
        (async () =>{
            try{
                const response = await axios.get("api/users",{headers : {
                    Authorization : localStorage.getItem('token')
                }})
                dispatch({type : "SET_USERS", payload : response.data })
                console.log(response.data)
            }catch(e){
                console.log(e)
            } 
        })()
    },[])

    useEffect(()=>{
        (async () =>{
            try{
                const response = await axios.get("api/matches",{headers : {
                    Authorization : localStorage.getItem('token')
                }})
                setMatches(response.data)
                console.log(response.data)
            }catch(e){
                console.log(e)
            } 
        })()
    },[])

    const handleClick = async (id,status) =>{

        const body = {
            id,
            status
        }
        const confirm =  window.confirm("are you sure")

        if(confirm){
            try{
                const response = await axios.put("api/users",body,{headers : {
                    Authorization : localStorage.getItem('token')
                }})
                setMatches(response.data)
                console.log(response.data)
            }catch(e){
                console.log(e)
            } 
        }
    }

    {console.log(users)}

    return(
        <div>
            <button onClick={test}>test</button>
            <Row>
                <Col md = {2}>
                
                </Col>
                <Col md = {8}>
                <Tabs className="match-tabs" justify>
                <Tab eventKey="Users" title = "Users">
                    <div className="search-user">
                    <input type="text" value={search} placeholder="search by username" onChange={(e)=>setSearch(e.target.value)}></input>
                    </div>
                    <Table className="users-table" striped bordered hover>
                        <thead>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            {users.filter(ele => ele.username.includes(search)).map(ele =>{
                                if(ele.role !== "admin"){
                                    return(
                                        <tr>
                                            <td>{ele.username}</td>
                                            <td>{ele.email}</td>
                                            <td>{ele.mobile}</td>
                                            <td><Button onClick={()=>handleClick(ele._id,ele.isActive)} size="sm" 
                                                variant={ele.isActive ? "danger" : "primary" }>
                                                {ele.isActive ? "DE-ACTIVATE" : "ACTIVATE" }
                                            </Button>
                                            </td>
                                        </tr>
                                    )
                                }
                            })}
                        </tbody>
                    </Table>
                </Tab>
                <Tab eventKey="Matches" title = "Matches">
                    <Table striped bordered hover responsive>
                        <thead>
                            <th>id</th>
                            <th>Match</th>
                            <th>Date</th>
                            <th>Players</th>
                            <th>Contest</th>
                            <th>revenue</th>
                        </thead>
                        <tbody>
                            {matches.map(ele => {
                                return(
                                    <tr>
                                        <td>{ele._id}</td>
                                        <td>{ele.team1} vs {ele.team2}</td>
                                        <td>{ele.deadline}</td>
                                        <td>{ele._id}</td>
                                        <td>{ele._id}</td>
                                        <td>{ele._id}</td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </Table>
                </Tab>
            </Tabs>
                </Col>
                <Col md = {2}>
                
                </Col>
            </Row>
            
        </div>
    )
}