import { useState } from "react";
import { Button, Modal, } from "react-bootstrap";
import axios from "../../Axios/axios";
import { useDispatch, useSelector } from "react-redux";
import { debitWallet } from "../../Actions/walletAction";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { getStartUser } from "../../Actions/userAction";

export default function JoinContest({closeModal,ele,team,fetchContest}){

    const [modal,setModal] = useState(true)
    const dispatch = useDispatch()

    const wallet = useSelector(state =>{
        return state.wallet
    })

    const handleClick = async (team) => {

        if(wallet.amount < ele.entryFee){
            Swal.fire({
                imageUrl : "https://cdni.iconscout.com/illustration/premium/thumb/empty-wallet-4790943-3989296.png?f=webp",
                imageHeight : 200,
                title: "Low Wallet Balance",
                html: `
                    <a href="/dashboard">Add money</a>
                `,
              })
        }else{
            
                    try{
                        const response = await axios.put(`api/contest/${ele._id}`,team,{
                            headers : {
                                Authorization : localStorage.getItem('token')
                            }
                        })
                        closeModal()
                        fetchContest()
                        console.log(response)
                        toast.success("contest joined successfully")
                        dispatch(getStartUser())
                        dispatch(debitWallet(response.data.entryFee))
                            
                    }catch(e){
                        console.log(e)
                    }
        }
    }

    return(
        <div>
            <Modal show = {modal} onHide={()=>{
                setModal(false)
                closeModal()
                }}>
                <Modal.Header closeButton>Confirmation</Modal.Header>
                <Modal.Body>
                    <p>Entry - {ele.totalPrize}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={()=>handleClick(team)}>Pay {ele.entryFee}</Button>
                </Modal.Footer>
            </Modal>
            <ToastContainer/>
        </div>
    )
}