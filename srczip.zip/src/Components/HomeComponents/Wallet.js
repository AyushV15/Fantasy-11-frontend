export default function Wallet({Wallet}){
    return(
        <div>
            <h1>Wallet</h1>
        </div>
    )
}