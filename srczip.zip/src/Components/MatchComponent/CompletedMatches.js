import { Card,Image,Button } from "react-bootstrap"
import { useNavigate } from "react-router-dom"
const _ = require('lodash')

export default function CompletedMatches({user}){

  const navigate = useNavigate()

    return(
        <div>
            {Object.keys(user).length > 0  && _.uniqBy(user.contests,"matchid._id").map(ele =>{
              if(ele.matchid.isCompleted)
              return(
                <Card className="text-center">
                        <Card.Header className="cardheader">{ele.matchid.tournament}</Card.Header>
                        <Card.Body className="card-body">
                <Card.Title >
                <p>{ele.matchid.team1} vs {ele.matchid.team2}</p>
                <Image src={`http://localhost:3300/uploads/images/${ele.matchid.team1logo}`}  style={{height : "150px"}} className="team1"/>  
                  VS  
                <Image src={`http://localhost:3300/uploads/images/${ele.matchid.team2logo}`}  style={{height : "150px"}} className="team2"/>
                </Card.Title>
                <Button variant="primary" size="sm" onClick={()=>navigate(`/match/${ele.matchid._id}`)}>View Match</Button>
              </Card.Body>
              </Card>
              )
            })}
        </div>
    )
}