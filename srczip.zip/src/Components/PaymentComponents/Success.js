import { Image } from "react-bootstrap";
import { Link } from "react-router-dom";
import money from "../../Images/money3.gif"

export default function Success(){
    return(
        <div>
        <div className="success">
            <h1>Payment Successful</h1>
            <Image src={money}/>
            <Link to={'/dashboard'}>Go to DashBoard</Link>
        </div>
        </div>
            
    )
}