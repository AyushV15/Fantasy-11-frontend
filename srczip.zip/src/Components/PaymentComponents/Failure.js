import "./Success.css"

export default function Failure(){
    return(
        <div>
            Failure
        </div>
    )
}