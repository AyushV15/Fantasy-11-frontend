import {Box,Stepper,Step,StepLabel,Button,Typography} from '@mui/material'
import {Tabs,Tab,ListGroup,Image, Row, Col, Modal, Table} from "react-bootstrap"
import { ToastContainer, toast } from 'react-toastify';
import { jwtDecode } from 'jwt-decode';
import 'react-toastify/dist/ReactToastify.css';
import "./CreateTeam.css"
import Countdown from 'react-countdown';
import {MatchContext} from "../../Context/Context"
import { useContext, useEffect, useReducer, useState } from "react"
import { useNavigate, useParams ,useHistory } from "react-router-dom"
import axios from "../../Axios/axios"

const teamReducer = (state,action) => {
    switch(action.type){
       case "ADD_PLAYER" : {
            return [...state,action.payload]
        }
       case "REMOVE_PLAYER" : {
            return state.filter(e => e._id !== action.payload._id)
       } 
       case "SET_TEAM" : {
            return [...action.payload]
       }
       default : {
        return [...state]
       }
    }
}

export default function CreateTeam(){

    const [steps,setSteps] = useState([1,2,3,4,5,6,7,8,9,10,11])
    
    // const [team,setTeam] = useState([])
    const [edit,setEdit] = useState(false)
    const [team,dispatch] = useReducer(teamReducer,[])
    const [modal,setModal] = useState(false)
    const [captain,setCaptain] = useState("")
    const [viceCaptain,setViceCaptain] = useState("")
    
    const {id} = useParams()
    const navigate = useNavigate()

    const {matches} = useContext(MatchContext)
    const match = matches.find(ele => ele._id == id)

    // useEffect(()=>{ // getting a single match from the database
    //     (async () =>{
    //         try{
    //             const response = await axios.get(`api/match/${id}`,{headers : {
    //                 Authorization : localStorage.getItem("token")
    //             }})
    //             setMatch(response.data)  //setting the macth to a  state varaible
    //             console.log(response.data)
                
    //         }catch(e){
    //             console.log(e)
    //         }
    //     })()
    // },[]) prevoius code

    console.log(edit ,"edit")
    useEffect(()=>{ // getting users team from database
        (async() =>{
            try{
                const response = await axios.get(`api/match/${id}/team`,{headers : {
                    Authorization : localStorage.getItem("token")
                }})
                console.log(response.data,"users team")
                if(response.data){
                    setEdit(true)
                }
                if(response.data){
                    dispatch({type : "SET_TEAM" , payload : response.data.team})
                }
                
            }catch(e){
                console.log(e)
            }
        })()
    },[])

    const selectCVC = () =>{
        if(team.filter(e => e.role == "wk").length < 1){
            return toast.info("Please Select Atleast One Wicket Keeper")
        }
        if(team.filter(e => e.role == "bat").length < 3){
            return toast.info("Please Select Atleast 2 Batsman")
        }
        if(team.filter(e => e.role == "all").length < 1){
            return toast.info("Please Select Atleast One Allrounder")
        }
        if(team.filter(e => e.role == "bowl").length < 2){
            return toast.info("Please Select Atleast 3 Bowlers")
        }
        setModal(true)
    }
    
    const handleSubmit = async () =>{ 
        const finalTeam = team.map(ele =>{
            if(ele.name == captain){
                return {...ele , C : true , VC : false}
            }
            else if(ele.name == viceCaptain){
                return {...ele, VC : true , C : false}
            }
            else{
                return {...ele , C: false , VC : false}
            }
        })

        const formdata = {
            team : finalTeam  
        }
        console.log(finalTeam)
        if(!edit){
            try{
                const response = await axios.post(`api/match/${id}/create-team`,formdata,{
                    headers : {
                        Authorization : localStorage.getItem("token")
                    }
                })
                console.log(response)
                navigate(`/match/${id}`,{replace :true})
            }catch(e){
                console.log(e)
            }
        }else{
            try{
                const response = await axios.put(`api/match/${id}/edit-team`,formdata,{
                    headers : {
                        Authorization : localStorage.getItem("token")
                    }
                })
                console.log(response)
                navigate(`/match/${id}`,{replace :true})
            }catch(e){
                console.log(e)
            }
        }

    } 

    return(
        <div>
             <div className="match-countdown">
                {match && (
                <Countdown
                date={(Date.now() + (new Date(match.deadline).getTime() - Date.now()))}
                onComplete={()=>{
                    alert("Deadline has passed")
                    navigate('/dashboard')
                }}
                />
                )}
            </div>
            <Stepper activeStep={team.length} style={{ background: 'black', padding: '10px', color : "green" }}>
                {steps.map(ele =>{
                    return(
                        <Step >
                            <StepLabel></StepLabel>
                        </Step>
                    )
                })}
            </Stepper>
            <div className='create-team-inst'>
                <p>Select Minimun - Wicketkeeper : 1 , Batsman : 3 , Allrounder : 1 , Bowler : 3</p>
            </div>
            <Row>
                <Col md = {3}></Col>
                <Col md = {6}>
            <Tabs className="match-tabs" defaultActiveKey="wicketkeeper" id="justify-tab-example" justify>
                <Tab eventKey={"wicketkeeper"} title = "Wicketkeeper">
                    <ListGroup >
                        {match && match.team1players.map(ele =>{
                           if(ele.role == "wk"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER", payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item> 

                           }
                        })}
                        {match && match.team2players.map(ele =>{
                           if(ele.role == "wk"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER", payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                    </ListGroup>

                </Tab>

                <Tab eventKey={"batsam"} title = "Batsman">
                    <ListGroup>
                        {match && match.team1players.map(ele =>{
                           if(ele.role == "bat"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type: "ADD_PLAYER", payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           } 
                        })}
                        {match && match.team2players.map(ele =>{
                           if(ele.role == "bat"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type: "ADD_PLAYER", payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                    </ListGroup>
                </Tab>

                <Tab eventKey={"allrounder"} title = "Allrounder">
                    <ListGroup>
                        {match && match.team1players.map(ele =>{
                           if(ele.role == "all"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER",payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                        {match && match.team2players.map(ele =>{
                           if(ele.role == "all"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER",payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                    </ListGroup>
                </Tab>

                <Tab eventKey={"bowler"} title = "Bowler">
                    <ListGroup>
                        {match && match.team1players.map(ele =>{
                           if(ele.role == "bowl"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER",payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                        {match && match.team2players.map(ele =>{
                           if(ele.role == "bowl"){
                            return <ListGroup.Item active = {team.find(e => e._id == ele._id)}>
                                <Image src = {`http://localhost:3300/uploads/players/${ele.pic}.avif`} style={{height : "70px"}}/>
                                {ele.name}
                                {team.find(e => e._id == ele._id) ? (
                                    <Button className='float-end' onClick={()=>dispatch({type : "REMOVE_PLAYER" ,payload : ele})}>➖</Button>
                                    ):(
                                    <Button disabled = {team.length == 11} className='float-end' onClick={()=>dispatch({type : "ADD_PLAYER",payload : ele})}>➕</Button>
                                )}
                            </ListGroup.Item>
                           }
                        })}
                    </ListGroup>
                </Tab>
            </Tabs>
            </Col>
            <Col md = {3}>
                <div>
                {team.length == 11 && <button onClick={selectCVC}>select Captain / Vice Captain</button>}
                </div>
            </Col>
            <ToastContainer/>
            </Row>
            
            <Modal show = {modal} onHide={()=>{
                setModal(false)
                setCaptain("")
                setViceCaptain("")
            }}>
                <Modal.Body>
                    <Table>
                        <thead>
                            <tr>
                                <th>Players</th>
                                <th>C</th>
                                <th>VC</th>
                            </tr>
                        </thead>
                        <tbody>
                    {team.map(ele =>{
                        return(
                            <tr>
                                <td>{ele.name}</td>
                                <td>
                                <input type='radio' name='C' disabled = {ele.name == viceCaptain}
                                value={ele.name} onChange={(e)=>setCaptain(e.target.value) }
                                /> 
                                </td>
                                <td>
                                <input type='radio'name='VC' value={ele.name} onChange={(e)=>setViceCaptain(e.target.value)}
                                disabled = {ele.name == captain}/>
                                </td>
                            </tr>
                        )
                    })}

                        </tbody>
                    </Table>
                    
                </Modal.Body> 
                <Modal.Footer>

                    <Button onClick={handleSubmit}
                    disabled = {captain == "" || viceCaptain == ""}
                    variant='primary'>Submit</Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}